#!/bin/bash

if [[ "$1" == "-h" ]]; then
	echo "Uso: [directorio_origen] [directorio_destino]"
	echo "Ejemplo: /var/log /backup_dir"
fi

if [[ "$1" != "/var/log" && "$1" != "/www_dir" ]]; then
	echo "Error: El primer argumento debe ser /var/log o /www_dir"
	exit 
fi

if [[ "$2" != "/backup_dir" ]]; then
	echo "El directorio destino debe ser /backup_dir"
	exit
fi

if [[ ! -d "$1" ]]; then
	echo "Error: El directorio de origen $1 no existe."
	exit 
fi

if [[ ! -d "$2" ]]; then
	echo "Error: El directorio de destino $2 no existe."
	exit 
fi

FECHA=$(date +%Y%m%d)
ORIGEN=$1
DESTINO=$2
NOMBRE_FINAL=$(basename "$ORIGEN")"_bkp_""$FECHA"".tar.gz"

#echo $FECHA
#echo $ORIGEN
#echo $DESTINO
#echo $NOMBRE_FINAL

tar -czf $NOMBRE_FINAL $ORIGEN
cp $NOMBRE_FINAL $DESTINO
rm $NOMBRE_FINAL
